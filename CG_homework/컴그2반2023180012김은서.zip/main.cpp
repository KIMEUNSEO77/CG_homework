#include <glew.h>
#include <freeglut.h>
#include <freeglut_ext.h> 
#include <glm/glm.hpp>
#include <glm/ext.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "filetobuf.h"
#include "shaderMaker.h"
#include "obj_load.h"
#include <random>
#include <vector>

// �̷�
#include <algorithm>
#include <stack>
#include <utility>

#include <cmath>

void make_vertexShaders();
void make_fragmentShaders();
GLuint make_shaderProgram();
GLvoid drawScene();
GLvoid Reshape(int w, int h);

Mesh gCube;
int cubeCount_x = 0;    // ���� ����
int cubeCount_z = 0;    // ���� ����

bool animationActive = true; float currentY = -3.0f;
bool orthoMode = false;  // ���� ���� ���
float moveCubeZ = 0.0f;      // z�� �̵�
bool updownAnimation = false;   // ���Ʒ� �ִϸ��̼�
bool rotatingYPlus = false;    // Y�� �߽� ���� ���� ȸ��
bool rotatingYMinus = false;  // y�� �߽� ���� ���� ȸ��
float angleCameraY = 0.0f; // ī�޶� Y�� ȸ�� ����

// �̷�
bool mazeMode = false;   // �̷� ���
bool lowMode = false;    // ���� �� ���(��������, �������� ����� ��)
bool playerActive = false; // �÷��̾� �ִ��� ������

// �κ�
float moveX = 0.0f; float moveZ = 0.0f; float moveSpeed = 0.1f;
float angleY = 0.0f;  // ������ �� ���� (�κ� ��ü ����)
float angleArm_X = 0.0f;   //  �� ����
int dir = 1;
float angleLeg_X = 0.0f;   //  �ٸ� ����

float limitAngleX = 45.0f; float limitAngleY = 10.0f;
bool cameraPOV = false; // ī�޶� ���� ���(true: �κ� 1��Ī ����. false: �⺻ 3��Ī ����)

// ����
bool lightMode = true;

struct Cube
{
	glm::vec3 position;
	glm::vec3 color;
	float height;
	float currentY;  // ���� y ��ġ
	bool goingUp;    // ���� ���� ������
	float moveingSpeed;  // �����̴� �ӵ�

	bool active = true; // �̷� ��忡�� �׸��� ���� (�׸��� ��)
};
std::vector<std::vector<Cube>> cubes;

static std::mt19937 rng(std::random_device{}());

void GenerateMaze()
{
	// ¦���� �ϳ� �ٿ��� ����
	if (cubeCount_x % 2 == 0) cubeCount_x -= 1;
	if (cubeCount_z % 2 == 0) cubeCount_z -= 1;

	// ��� ĭ�� �ʱ�ȭ
	for (int i = 0; i < cubeCount_x; ++i)
		for (int j = 0; j < cubeCount_z; ++j)
			cubes[i][j].active = true;

	// �湮ǥ��
	std::vector<std::vector<bool>> vis(cubeCount_x, std::vector<bool>(cubeCount_z, false));

	auto in = [&](int x, int z) 
		{
		return (x > 0 && x < cubeCount_x - 1 && z > 0 && z < cubeCount_z - 1);
		};

	// ���� �κ�
	int sx = 1, sz = 1;
	vis[sx][sz] = true;
	cubes[sx][sz].active = false; // ��

	std::stack<std::pair<int, int>> st;
	st.push({ sx, sz });

	// �̿� ���� 2ĭ�� �̵�
	const int dx[4] = { +2, -2, 0, 0 };
	const int dz[4] = { 0, 0, +2, -2 };

	while (!st.empty())
	{
		auto cur = st.top();
		int x = cur.first;
		int z = cur.second;

		// �湮���� ���� �̿�
		std::vector<int> cand;
		for (int k = 0; k < 4; ++k)
		{
			int nx = x + dx[k];
			int nz = z + dz[k];
			if (in(nx, nz) && !vis[nx][nz] && (nx % 2 == 1) && (nz % 2 == 1))
				cand.push_back(k);
		}

		if (cand.empty())
		{
			st.pop();
			continue;
		}

		// ���� �̿� �ϳ� ����
		std::shuffle(cand.begin(), cand.end(), rng);
		int k = cand.front();
		int nx = x + dx[k];
		int nz = z + dz[k];

		// ����(x,z)�� (nx,nz) ������ ��(1ĭ ����)�� ����
		int wx = x + dx[k] / 2;
		int wz = z + dz[k] / 2;

		vis[nx][nz] = true;
		cubes[nx][nz].active = false; // ��
		cubes[wx][wz].active = false; // �� ����(��)

		st.push({ nx, nz });
	}

	cubes[1][0].active = false;                               // �Ա�
	cubes[cubeCount_x - 2][cubeCount_z - 1].active = false;   // �ⱸ
}

float randomFloat(float a, float b)
{
	std::random_device rd;
	std::mt19937 gen(rd());  // Mersenne Twister ����
	std::uniform_real_distribution<float> dist(a, b);

	return dist(gen);
}

// ť��� ���� �ʱ�ȭ
void InitCube()
{
	cubes.resize(cubeCount_x);
	for (int i = 0; i < cubeCount_x; ++i)
		cubes[i].resize(cubeCount_z);

	for (int i = 0; i < cubeCount_x; ++i)
	{
		for (int j = 0; j < cubeCount_z; ++j)
		{
			cubes[i][j].position = glm::vec3(-2.0f + i, 0.0f, -3.0f + j);
			cubes[i][j].color = glm::vec3(randomFloat(0.1f, 1.0f),
				randomFloat(0.1f, 1.0f), randomFloat(0.1f, 1.0f));
			cubes[i][j].height = randomFloat(9.0f, 17.0f);
			cubes[i][j].currentY = -10.0f;
			cubes[i][j].goingUp = rand() % 2;                    // ���� ����
			cubes[i][j].moveingSpeed = randomFloat(0.01f, 0.3f); // �ӵ� ����
		}
	}
}

// ����ڿ��� ������ü�� ���� �Է� �ޱ�
void InputCubeCount()
{
	std::cout << "����, ���� ���� 5~25 �Է�: ";
	std::cin >> cubeCount_x >> cubeCount_z;
	std::cout << "���� ����: " << cubeCount_x << ", ���� ����: " << cubeCount_z << std::endl;
	
	if (cubeCount_x < 5 || cubeCount_x > 25)
	{
		std::cerr << "���� ���� �߸� �Է�" << std::endl;
		InputCubeCount();
	}

	if (cubeCount_z < 5 || cubeCount_z > 25)
	{
		std::cerr << "���� ���� �߸� �Է�" << std::endl;
		InputCubeCount();
	}
	InitCube();   // ť��� ���� �ʱ�ȭ
}

void SpeedChange(float delta)
{
	for (int i = 0; i < cubeCount_x; ++i)
	{
		for (int j = 0; j < cubeCount_z; ++j)
		{
			cubes[i][j].moveingSpeed += delta;
			if (cubes[i][j].moveingSpeed <= 0.002f)
				cubes[i][j].moveingSpeed = 0.002f;
			if (cubes[i][j].moveingSpeed >= 0.5f)
				cubes[i][j].moveingSpeed = 0.5f;
		}
	}
}

void LowMode()
{
	for (int i = 0; i < cubeCount_x; ++i)
	{
		for (int j = 0; j < cubeCount_z; ++j)
		{
			if (!cubes[i][j].active) continue;  // �ִϸ��̼� x
			cubes[i][j].currentY = -0.5f;
			cubes[i][j].height = 5.0f;
		}
	}
}

// �ܼ�â�� ���ɾ�� ���
void PrintInstructions()
{
	std::cout << "<<Ű���� ���ɾ��>>\n";
	std::cout << "o: ���� ���� ���\n";
	std::cout << "p: ���� ���� ���\n";
	std::cout << "z: z�� ���� ���� �̵�\n";
	std::cout << "Z: z�� ���� ���� �̵�\n";
	std::cout << "m: ť����� ���Ʒ��� ������ ����\n";
	std::cout << "M: ť����� ���Ʒ��� ������ ����\n";
	std::cout << "y: ī�޶� Y�� �߽� ���� ���� ȸ�� ����/����\n";
	std::cout << "Y: ī�޶� Y�� �߽� ���� ���� ȸ�� ����/����\n";
	std::cout << "+: ť�� ������ �ӵ� ����\n";
	std::cout << "-: ť�� ������ �ӵ� ����\n";
	std::cout << "r: �̷� ����(���� ������ ���ο� �̷ΰ� ���۵�)\n";
	std::cout << "v: ���� �� ��� ����, ������ ����/����\n";
	std::cout << "s: �÷��̾�(�κ�) ����\n";
	std::cout << "����Ű: �÷��̾� �̵�\n";
	std::cout << "1: �κ� 1��Ī ���� ī�޶� ���\n";
	std::cout << "3: �⺻ 3��Ī ���� ī�޶� ���\n";
	std::cout << "c: ��� �� �ʱ�ȭ\n";
	std::cout << "q: ����\n";
}

void MoveArmX()
{
	if (angleArm_X > limitAngleX) dir = -1;
	else if (angleArm_X < -limitAngleX) dir = 1;
	angleArm_X += dir * 2.0f;

	if (angleLeg_X > limitAngleY) dir = -1;
	else if (angleLeg_X < -limitAngleY) dir = 1;
	angleLeg_X += dir * 1.0f;
}

// �÷��̾� ��ġ�� ť��� �浹�ϴ��� Ȯ���ϴ� �Լ�
bool IsCollidingWithCube(float nextX, float nextZ)
{
	// moveX,moveZ�� ���� ���� ��ǥ�� ��ȯ
	float playerX = nextX * 0.5f;
	float playerZ = nextZ * 0.5f - 5.0f;

	// �÷��̾� ������, ť�� ������
	float playerHalf = 0.25f;
	float cubeHalf = 0.5f;

	for (int i = 0; i < cubeCount_x; ++i)
	{
		for (int j = 0; j < cubeCount_z; ++j)
		{
			if (!cubes[i][j].active) continue;  // ���� ����

			// ť���� ���� ���� ��ǥ
			float cubeX = cubes[i][j].position.x;
			float cubeZ = cubes[i][j].position.z + moveCubeZ; 

			// AABB �浹 üũ
			float dx = std::fabs(playerX - cubeX);
			float dz = std::fabs(playerZ - cubeZ);

			if (dx < playerHalf + cubeHalf &&
				dz < playerHalf + cubeHalf)
			{
				// �浹
				return true;
			}
		}
	}
	return false;
}


// X�� �̵� �Լ�
void MoveX(float speed)
{
	float nextX = moveX + speed;
	if (!IsCollidingWithCube(nextX, moveZ))
	{
		moveX = nextX;
		glutPostRedisplay();
	}
}

// Z�� �̵� �Լ�
void MoveZ(float speed)
{
	float nextZ = moveZ + speed;
	if (!IsCollidingWithCube(moveX, nextZ))
	{
		moveZ = nextZ;
		glutPostRedisplay();
	}
}

void IncreaseSpeed(float delta)
{
	moveSpeed += delta;
	if (moveSpeed < 0.01f) moveSpeed = 0.01f;
	if (moveSpeed > 0.2f) moveSpeed = 0.2f;

	if (delta > 0)
	{
		if (limitAngleX < 60.0f)
			limitAngleX += 3.0f;
		if (limitAngleY < 20.0f)
			limitAngleY += 1.0f;
	}
	else
	{
		if (limitAngleX > 15.0f)
			limitAngleX -= 3.0f;
		if (limitAngleY > 5.0f)
			limitAngleY -= 1.0f;
	}
}

void Timer(int value)
{
	if (animationActive)
	{
		for (int i = 0; i < cubeCount_x; ++i)
		{
			for (int j = 0; j < cubeCount_z; ++j)
			{
				if (!cubes[i][j].active) continue;  // �ִϸ��̼� x

				cubes[i][j].currentY += 0.1f;

				if (cubes[i][j].currentY >= -3.0f)
				{
					cubes[i][j].currentY = -3.0f;
					animationActive = false;
				}					
			}
		}
	}

	if (updownAnimation)
	{
		for (int i = 0; i < cubeCount_x; ++i)
		{
			for (int j = 0; j < cubeCount_z; ++j)
			{
				if (!cubes[i][j].active) continue;  // �ִϸ��̼� x

				if (cubes[i][j].goingUp)
				{
					cubes[i][j].currentY += cubes[i][j].moveingSpeed;
					if (cubes[i][j].currentY >= -1.5f)
						cubes[i][j].goingUp = false;
				}
				else
				{
					cubes[i][j].currentY -= cubes[i][j].moveingSpeed;
					if (cubes[i][j].currentY <= -5.0f)
						cubes[i][j].goingUp = true;
				}
			}
		}
	}

	if (rotatingYPlus) angleCameraY += 0.2f;
	if (rotatingYMinus) angleCameraY -= 0.2f;

	glutPostRedisplay();
	glutTimerFunc(16, Timer, 0);
}

// ����
void ResetAll()
{
	cubes.clear();
	animationActive = true;
	orthoMode = false;
	moveCubeZ = 0.0f;
	updownAnimation = false;
	rotatingYPlus = false;
	rotatingYMinus = false;
	angleCameraY = 0.0f;
	mazeMode = false;
	lowMode = false;
	playerActive = false;
	moveX = 0.0f; moveZ = 0.0f; moveSpeed = 0.1f;
	angleY = 0.0f;
	angleArm_X = 0.0f;
	angleLeg_X = 0.0f;
	limitAngleX = 45.0f; limitAngleY = 10.0f;
	if (cubeCount_x > 0 && cubeCount_z > 0)
		InitCube();
	glutPostRedisplay();
}

GLvoid Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'o': orthoMode = true; glutPostRedisplay(); break;
	case 'p': orthoMode = false; glutPostRedisplay(); break;
	case 'z': if (!orthoMode) moveCubeZ += 1.0f; glutPostRedisplay(); break;
	case 'Z': if (!orthoMode) moveCubeZ -= 1.0f; glutPostRedisplay(); break;
	case 'm': updownAnimation = true; break;
	case 'M': updownAnimation = false; break;
	case '+': SpeedChange(0.01f); break;
	case '-': SpeedChange(-0.01f); break;
	case 'y': rotatingYPlus = !rotatingYPlus; rotatingYMinus = false; break;
	case 'Y': rotatingYMinus = !rotatingYMinus; rotatingYPlus = false; break;
	case 'r': mazeMode = true; GenerateMaze(); glutPostRedisplay(); break;
	case 'v': updownAnimation = !updownAnimation; LowMode(); glutPostRedisplay(); break;
	case 's': playerActive = true; glutPostRedisplay(); break;
	case '1': cameraPOV = true; glutPostRedisplay(); break;
	case '3': cameraPOV = false; glutPostRedisplay(); break;
	case 'c': ResetAll(); break;
	case 'q': exit(0); break;
	}
}

void SpecialKeyboard(int key, int x, int y)
{
	switch (key)
	{
	case GLUT_KEY_UP: if (playerActive) { MoveZ(-moveSpeed); angleY = 180.0f; MoveArmX(); }  break;
	case GLUT_KEY_DOWN: if (playerActive) { MoveZ(moveSpeed); angleY = 0.0f; MoveArmX(); }break;
	case GLUT_KEY_LEFT: if (playerActive) { MoveX(-moveSpeed); angleY = -90.0f; MoveArmX(); } break;
	case GLUT_KEY_RIGHT: if (playerActive) { MoveX(moveSpeed);  angleY = 90.0f; MoveArmX(); } break;
	}
	glutPostRedisplay();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);  // ���� ���� �߰�
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(width, height);
	glutCreateWindow("2025_ComputerGraphics_Homework");

	glutDisplayFunc(drawScene);
	glutReshapeFunc(Reshape);

	glewExperimental = GL_TRUE;
	glewInit();

	glEnable(GL_DEPTH_TEST); // ���� �׽�Ʈ Ȱ��ȭ
	// ���� ���� ���� �ϴ���
	InputCubeCount();   // ť�� ���� �Է� �ޱ�

	make_vertexShaders();
	make_fragmentShaders();
	shaderProgramID = make_shaderProgram();

	if (!LoadOBJ_PosNorm_Interleaved("unit_cube.obj", gCube)) 
	{
		std::cerr << "Failed to load unit_cube.obj\n";
		return 1;
	}

	PrintInstructions();  // �ܼ�â�� ���ɾ�� ���

	glutKeyboardFunc(Keyboard);
	glutTimerFunc(0, Timer, 0); // Ÿ�̸� ����
	glutSpecialFunc(SpecialKeyboard);
	glutMainLoop();

	return 0;
}

// ť�� �׸��� �Լ�
void DrawCube(const Mesh& mesh, GLuint shaderProgram, const glm::mat4& model, const glm::vec3& color)
{
	GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, &model[0][0]);

	GLint colorLoc = glGetUniformLocation(shaderProgram, "objectColor");
	glUniform3fv(colorLoc, 1, &color[0]);

	glBindVertexArray(mesh.vao);
	glDrawArrays(GL_TRIANGLES, 0, mesh.count);
	glBindVertexArray(0);
}

GLvoid drawScene()
{
	glViewport(0, 0, width, height);
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glUseProgram(shaderProgramID);

	GLint viewLoc = glGetUniformLocation(shaderProgramID, "view");
	GLint projLoc = glGetUniformLocation(shaderProgramID, "projection");

	// ���� �ѱ� ����
	GLuint lightOnLoc = glGetUniformLocation(shaderProgramID, "lightOn");
	glUniform1i(lightOnLoc, lightMode ? 1 : 0);

	// ����, ��ü �� ����
	GLint lightLoc = glGetUniformLocation(shaderProgramID, "lightColor");
	GLint objLoc = glGetUniformLocation(shaderProgramID, "objectColor");

	// ���� ��ġ
	glm::vec3 lightPos;
	if (playerActive) lightPos = glm::vec3(moveX * 0.5f, 2.0f + cubeCount_z * 0.03f, moveZ * 0.5f - 5.0f);
	else  lightPos = glm::vec3(1.0f, 3.0f, 2.5f);

	GLint uLightPos = glGetUniformLocation(shaderProgramID, "lightPos");  // ���� ��ġ
	GLuint viewPosLoc = glGetUniformLocation(shaderProgramID, "viewPos");    // ī�޶� ��ġ
	glUniform3f(lightLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(objLoc, 1.0f, 0.7f, 0.7f);      // ������Ʈ ��
	glUniform3f(uLightPos, lightPos.x, lightPos.y, lightPos.z); // ���� ��ġ

	glm::vec3 cameraPos, cameraDirection, cameraUp;
	float centerX = (cubeCount_x - 1) / 2.0f;
	float centerZ = (cubeCount_z - 1) / 2.0f;

	if (cameraPOV && playerActive)
	{
		float cameraDistance = 1.0f;
		float rad = glm::radians(angleY);
		constexpr float pitch = glm::radians(-15.0f);

		// �κ� ��ġ
		glm::vec3 robotPos = glm::vec3(moveX * 0.5f, 2.0f + cubeCount_z * 0.03f, moveZ * 0.5f - 5.0f);

		// �κ��� �ٶ󺸴� ���� ����
		glm::vec3 forward = glm::vec3(
			sin(rad) * cos(pitch),
			sin(pitch),
			cos(rad) * cos(pitch)
		);

		// ī�޶� ��ġ
		cameraPos = robotPos - forward * cameraDistance;
		cameraDirection = robotPos;
		cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

		glm::mat4 vTransform = glm::lookAt(cameraPos, cameraDirection, cameraUp);
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, &vTransform[0][0]);
	}
	else 
	{
		// ���� 3��Ī ����
		cameraPos = glm::vec3(centerX, 0.0f, 15.0f + cubeCount_z);
		cameraDirection = glm::vec3(centerX, 0.0f, centerZ);
		cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

		glm::mat4 rotation = glm::rotate(glm::mat4(1.0f), glm::radians(angleCameraY), glm::vec3(0.0f, 1.0f, 0.0f))
			* glm::rotate(glm::mat4(1.0f), glm::radians(-15.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		cameraPos = glm::vec3(rotation * glm::vec4(cameraPos - cameraDirection, 1.0f)) + cameraDirection;

		glm::mat4 vTransform = glm::mat4(1.0f);
		vTransform = glm::lookAt(cameraPos, cameraDirection, cameraUp);
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, &vTransform[0][0]);
	}

	glm::mat4 pTransform = glm::mat4(1.0f);
	if (orthoMode)
	{
		float aspect = (float)width / (float)height;
		float margin = 1.0f;
		float maxH = 14.0f;
		float halfContentX = 0.5f * cubeCount_x + margin;
		float halfContentY = 0.5f * maxH + margin;

		// �� ū �ʿ� ���� Ȯ��
		float halfY = std::max(halfContentY, halfContentX / aspect);
		float halfX = halfY * aspect;

		pTransform = glm::ortho(-halfX, halfX, -halfY, halfY, 0.1f, 1000.0f);
	}
	else
		pTransform = glm::perspective(glm::radians(45.0f), (float)width / (float)height, 0.1f, 100.0f);

	glUniformMatrix4fv(projLoc, 1, GL_FALSE, &pTransform[0][0]);

	// �ٴ�
	glm::mat4 ground = glm::mat4(1.0f);
	ground = glm::translate(ground, glm::vec3(0.0f, -0.5f, 0.0f));
	ground = glm::scale(ground, glm::vec3(100.0f, 0.05f, 100.0f));
	DrawCube(gCube, shaderProgramID, ground, glm::vec3(0.0f, 0.0f, 0.0f));

	// ť���
	for (int i = 0; i < cubeCount_x; ++i)
	{
		for (int j = 0; j < cubeCount_z; j++)
		{
			if (!cubes[i][j].active) continue;  // ���� �׸��� ����

			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(cubes[i][j].position.x,
				cubes[i][j].currentY, cubes[i][j].position.z + moveCubeZ));
			model = glm::scale(model, glm::vec3(1.0f, cubes[i][j].height, 1.0f));
			DrawCube(gCube, shaderProgramID, model, cubes[i][j].color);
		}
	}

	if (playerActive)
	{
		// ť�� �׸���
		// ����
		glm::mat4 share = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 0.0f));
		share = glm::translate(share, glm::vec3(0.0f, -1.5f + cubeCount_z * 0.04f, -5.0f));
		share = glm::scale(share, glm::vec3(0.5f, 0.5f, 0.5f));

		// �κ� �׸���
		glm::mat4 robotBase = share;
		robotBase = glm::translate(robotBase, glm::vec3(moveX, 5.0f, moveZ));
		robotBase = glm::rotate(robotBase, glm::radians(angleY), glm::vec3(0.0f, 1.0f, 0.0f));
		// �Ӹ�
		glm::mat4 robotHead = robotBase;
		robotHead = glm::translate(robotHead, glm::vec3(0.0f, 0.0f, 0.0f));
		robotHead = glm::scale(robotHead, glm::vec3(1.0f, 1.0f, 1.0f));
		DrawCube(gCube, shaderProgramID, robotHead, glm::vec3(1.0f, 0.7f, 0.3f));

		// ��
		glm::mat4 robotNose = robotBase;
		robotNose = glm::translate(robotNose, glm::vec3(0.0f, 0.0f, 0.5f));
		robotNose = glm::scale(robotNose, glm::vec3(0.2f, 0.2f, 0.3f));
		DrawCube(gCube, shaderProgramID, robotNose, glm::vec3(1.0f, 0.0f, 0.0f));

		// ����
		glm::mat4 robotBody = robotBase;
		robotBody = glm::translate(robotBody, glm::vec3(0.0f, -1.0f, 0.0f));
		robotBody = glm::scale(robotBody, glm::vec3(1.0f, 1.5f, 1.0f));
		DrawCube(gCube, shaderProgramID, robotBody, glm::vec3(0.5f, 0.9f, 0.5f));

		// ����
		glm::mat4 robotArmL = robotBase;
		robotArmL = glm::rotate(robotArmL, glm::radians(angleArm_X), glm::vec3(1.0f, 0.0f, 0.0f));
		robotArmL = glm::translate(robotArmL, glm::vec3(-0.5f, -1.0f, 0.0f));
		robotArmL = glm::scale(robotArmL, glm::vec3(0.3f, 1.2f, 0.3f));
		DrawCube(gCube, shaderProgramID, robotArmL, glm::vec3(0.7f, 0.6f, 0.7f));
		// ������
		glm::mat4 robotArmR = robotBase;
		robotArmR = glm::rotate(robotArmR, glm::radians(-angleArm_X), glm::vec3(1.0f, 0.0f, 0.0f));
		robotArmR = glm::translate(robotArmR, glm::vec3(0.5f, -1.0f, 0.0f));
		robotArmR = glm::scale(robotArmR, glm::vec3(0.3f, 1.2f, 0.3f));
		DrawCube(gCube, shaderProgramID, robotArmR, glm::vec3(0.3f, 0.4f, 0.3f));

		// �޴ٸ�
		glm::mat4 robotLegL = robotBase;
		robotLegL = glm::rotate(robotLegL, glm::radians(-angleLeg_X), glm::vec3(1.0f, 0.0f, 0.0f));
		robotLegL = glm::translate(robotLegL, glm::vec3(-0.1f, -2.2f, 0.0f));
		robotLegL = glm::scale(robotLegL, glm::vec3(0.2f, 2.0f, 0.2f));
		DrawCube(gCube, shaderProgramID, robotLegL, glm::vec3(0.8f, 0.5f, 0.5f));
		// �����ٸ�
		glm::mat4 robotLegR = robotBase;
		robotLegR = glm::rotate(robotLegR, glm::radians(angleLeg_X), glm::vec3(1.0f, 0.0f, 0.0f));
		robotLegR = glm::translate(robotLegR, glm::vec3(0.1f, -2.2f, 0.0f));
		robotLegR = glm::scale(robotLegR, glm::vec3(0.2f, 2.0f, 0.2f));
		DrawCube(gCube, shaderProgramID, robotLegR, glm::vec3(0.5f, 0.5f, 0.8f));

	}

	// �̴ϸ� �׸��� 
	glViewport(600, 600, 300, 300);
	glm::vec3 miniCamPos = glm::vec3(centerX - 2.0f, 100.0f, centerZ - 2.0f); // ����
	glm::vec3 miniCamTarget = glm::vec3(centerX - 2.0f, 0.0f, centerZ - 2.0f);
	glm::vec3 miniCamUp = glm::vec3(0.0f, 0.0f, -1.0f); // z�� �Ʒ� ����

	glm::mat4 miniView = glm::lookAt(miniCamPos, miniCamTarget, miniCamUp);
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, &miniView[0][0]);

	glm::mat4 miniProj = glm::ortho(
		-cubeCount_x / 2.0f - 3.0f, cubeCount_x / 2.0f + 3.0f,
		-cubeCount_z / 2.0f - 3.0f, cubeCount_z / 2.0f + 3.0f,
		1.0f, 100.0f
	);
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, &miniProj[0][0]);

	// �ٴ�(�̴ϸʿ�)
	glm::mat4 groundMini = glm::mat4(1.0f);
	groundMini = glm::translate(groundMini, glm::vec3(0.0f, 0.0f, 0.0f));
	groundMini = glm::scale(groundMini, glm::vec3(100.0f, 0.05f, 100.0f));
	DrawCube(gCube, shaderProgramID, groundMini, glm::vec3(0.8f, 0.8f, 0.8f));

	// ť���
	for (int i = 0; i < cubeCount_x; ++i)
	{
		for (int j = 0; j < cubeCount_z; j++)
		{
			if (!cubes[i][j].active) continue;  

			glm::mat4 model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(cubes[i][j].position.x,
				cubes[i][j].currentY, cubes[i][j].position.z + moveCubeZ));
			model = glm::scale(model, glm::vec3(1.0f, cubes[i][j].height, 1.0f));
			DrawCube(gCube, shaderProgramID, model, cubes[i][j].color);
		}
	}

	if (playerActive)
	{
		// ť�� �׸���
		// ����
		glm::mat4 share = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 0.0f));
		share = glm::translate(share, glm::vec3(0.0f, 0.5f, -5.0f));
		share = glm::scale(share, glm::vec3(0.5f, 0.5f, 0.5f));

		// �κ� �׸���
		glm::mat4 robotBase = share;
		robotBase = glm::translate(robotBase, glm::vec3(moveX, 5.0f, moveZ));
		robotBase = glm::rotate(robotBase, glm::radians(angleY), glm::vec3(0.0f, 1.0f, 0.0f));
		// �Ӹ�
		glm::mat4 robotHead = robotBase;
		robotHead = glm::translate(robotHead, glm::vec3(0.0f, 0.0f, 0.0f));
		robotHead = glm::scale(robotHead, glm::vec3(1.0f, 1.0f, 1.0f));
		DrawCube(gCube, shaderProgramID, robotHead, glm::vec3(1.0f, 0.7f, 0.3f));

		// ��
		glm::mat4 robotNose = robotBase;
		robotNose = glm::translate(robotNose, glm::vec3(0.0f, 0.0f, 0.5f));
		robotNose = glm::scale(robotNose, glm::vec3(0.2f, 0.2f, 0.3f));
		DrawCube(gCube, shaderProgramID, robotNose, glm::vec3(1.0f, 0.0f, 0.0f));

		// ����
		glm::mat4 robotBody = robotBase;
		robotBody = glm::translate(robotBody, glm::vec3(0.0f, -1.0f, 0.0f));
		robotBody = glm::scale(robotBody, glm::vec3(1.0f, 1.5f, 1.0f));
		DrawCube(gCube, shaderProgramID, robotBody, glm::vec3(0.5f, 0.9f, 0.5f));

		// ����
		glm::mat4 robotArmL = robotBase;
		robotArmL = glm::rotate(robotArmL, glm::radians(angleArm_X), glm::vec3(1.0f, 0.0f, 0.0f));
		robotArmL = glm::translate(robotArmL, glm::vec3(-0.5f, -1.0f, 0.0f));
		robotArmL = glm::scale(robotArmL, glm::vec3(0.3f, 1.2f, 0.3f));
		DrawCube(gCube, shaderProgramID, robotArmL, glm::vec3(0.7f, 0.6f, 0.7f));
		// ������
		glm::mat4 robotArmR = robotBase;
		robotArmR = glm::rotate(robotArmR, glm::radians(-angleArm_X), glm::vec3(1.0f, 0.0f, 0.0f));
		robotArmR = glm::translate(robotArmR, glm::vec3(0.5f, -1.0f, 0.0f));
		robotArmR = glm::scale(robotArmR, glm::vec3(0.3f, 1.2f, 0.3f));
		DrawCube(gCube, shaderProgramID, robotArmR, glm::vec3(0.3f, 0.4f, 0.3f));

		// �޴ٸ�
		glm::mat4 robotLegL = robotBase;
		robotLegL = glm::rotate(robotLegL, glm::radians(-angleLeg_X), glm::vec3(1.0f, 0.0f, 0.0f));
		robotLegL = glm::translate(robotLegL, glm::vec3(-0.1f, -2.2f, 0.0f));
		robotLegL = glm::scale(robotLegL, glm::vec3(0.2f, 2.0f, 0.2f));
		DrawCube(gCube, shaderProgramID, robotLegL, glm::vec3(0.8f, 0.5f, 0.5f));
		// �����ٸ�
		glm::mat4 robotLegR = robotBase;
		robotLegR = glm::rotate(robotLegR, glm::radians(angleLeg_X), glm::vec3(1.0f, 0.0f, 0.0f));
		robotLegR = glm::translate(robotLegR, glm::vec3(0.1f, -2.2f, 0.0f));
		robotLegR = glm::scale(robotLegR, glm::vec3(0.2f, 2.0f, 0.2f));
		DrawCube(gCube, shaderProgramID, robotLegR, glm::vec3(0.5f, 0.5f, 0.8f));

	}

	glutSwapBuffers();
}

GLvoid Reshape(int w, int h)
{
	width = w;
	height = h;
	glViewport(0, 0, w, h);
}